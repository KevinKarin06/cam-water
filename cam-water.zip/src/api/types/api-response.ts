export interface ApiResponse {
  code: string;
  message: string;
  data?: any;
  statusCode?: number;
}
